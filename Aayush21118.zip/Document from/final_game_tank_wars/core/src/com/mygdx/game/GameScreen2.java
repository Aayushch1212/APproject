package com.mygdx.game;

public class GameScreen2 {
}
